# SurfAPI

## Principe de l'application

Utilisation d'une API, pour transmettre les meilleurs moments triés pour surfer dans la semaine selon des localisations renseignées par l'utilisateur.

Mode Automatique (Par exemple pour une Raspberry):
Toutes les 24h, vient vous envoyer un mail avec les données de la semaine

Cette application n'a pas pour but d'être partagé au public pour l'instant

## Utilisation de l'application

Ne nécessite pas de librairies particulières
Il suffit simplement de lancer à la racine du projet :

```python3 surfAPI.py```

Il n'y a plus qu'à lire les instructions
